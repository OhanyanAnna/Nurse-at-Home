from flask import Flask, render_template, request, redirect, url_for, flash
import os
import json


app = Flask(__name__)
app.secret_key = "your_secret_key"  # Secret key for session management

# Route for the homepage
@app.route('/')
def home():
    return render_template('home.html')

# Route for the login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        # Placeholder logic for login
        return redirect(url_for('profile'))
    return render_template('login.html')

# Route for the registration page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password == confirm_password:
            flash('Account created successfully! Please log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Passwords do not match. Please try again.', 'danger')
    return render_template('register.html')

# Route for the profile page
from datetime import datetime

@app.route('/profile')
def profile():
    current_year = datetime.now().year
    return render_template('profile.html', current_year=current_year)


# Route for the calendar
@app.route('/calendar')
def calendar():
    return render_template('calendar.html')

# Route for the nurses page
@app.route('/nurses')
def nurses_page():
    json_path = os.path.join('data', 'nurses.json')
    try:
        with open(json_path) as f:
            nurses = json.load(f)
            print("Loaded nurses:", nurses)  # Debugging line
    except FileNotFoundError:
        nurses = []
    return render_template('nurses.html', nurses=nurses)

# Main entry point
if __name__ == '__main__':
    app.run(debug=True)
